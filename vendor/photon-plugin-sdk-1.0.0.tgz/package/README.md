# Photon Plugin SDK

Version 1 provides typed, isolated access to Photon commands, native panels, dialogs,
documents, pixels, transactions, settings, credentials, files, and background jobs.

Use `definePlugin(async photon => { ... })` from a bundled browser entrypoint.
The complete guide and runnable examples live in the standalone Photon AI Studio
repository at `~/workspace/photon_plugin/docs`. Build with `npm run build` and distribute
with `npm pack`; no Photon internals or Electron imports are required by plugins.
